# AVTrack desktop review

Reviewed revision: `53386a0` / v0.0.187. Desktop walkthroughs used a 1440 × 1000 viewport, disposable SQLite databases, and test records. No production records were edited. This review simulates the perspectives of a first-time technician and an experienced broadcast supervisor; it is not a claim of real-world operational experience.

No interface redesign or mobile changes were applied or pushed for this review. Earlier backend validation experiments were preserved separately in `/workspace/avtrack-hardening-draft.patch`, with the application checkout restored to its original revision.

## Confirmed defects and misleading behavior

| Priority | Finding | Reproduction / evidence | Suggested correction |
| --- | --- | --- | --- |
| Critical | Complete JSON export fails. | GET `/api/workspace/export?format=json` returned HTTP 500. ZIP, XLSX, and CSV each returned 200. The download handler passes serialized bytes into a response helper that JSON-serializes its argument again. | Send serialized JSON bytes correctly and add HTTP-level download-and-restore tests for every supported format. |
| High | Confirmed locations counts records rather than distinct locations. | Two confirmed records in `Locker A` displayed `Locations: 1` and `Confirmed locations: 2`. | Define whether the metric means locations or items. For a location metric, count distinct locations and define partial confirmation when only some items there have been checked. |
| High | Stock totals can hide incomplete counts. | A record with quantity 3 and another with an unknown quantity displayed `Total units: 3` and `100% of units` confirmed. A tooltip explains that blank quantities are excluded; the main metric does not. | Display `3 known units · 1 record awaiting count`; distinguish completion of known stock from completion of the inventory. |
| High | Unit removal defaults to the first serial and uses whole-record deletion wording. | A three-unit row opened with `CAM-A` already selected, while the dialog said `Delete equipment?` and described removing the record and its quantity. | Start with no selection. Offer distinct `Remove one unit` and `Delete entire record` actions. Repeat the serial and resulting quantity in the confirmation and success message. |
| Medium | Unsaved manual entries disappear on close. | Entered a device name, closed the dialog, and reopened it; the field was blank with no discard confirmation. | Preserve a temporary draft or ask whether to discard changes. Keep it simple for an untouched form. |
| Medium | A manually added device can have no usable identity. | Saved a record containing only Notes; its device-name and IP cells were blank. | Warn before saving a manually entered record without a name or IP; offer `Save as incomplete`. Continue allowing incomplete spreadsheet imports, with visible review flags. |
| Medium | IPTV summary implies monitoring. | One saved channel displayed `channel running` without a stream check. | Say `channel saved` or `channel configured`. Show on-air status only when it is actually checked, with a timestamp and method. |

## First-time technician walkthrough

### Adding records

The app offers direct Add actions, but the first inventory creation ends with `Continue to paste`. Someone trying to add one spare part is taken into a spreadsheet workflow and has to cancel it before finding Add equipment.

Suggested flow: name the inventory, choose its type, then choose `Add first item` or `Import a spreadsheet`. Explain which fields are recommended and which can remain unknown. After saving, offer `Add another` without losing the current venue/location.

Duplicate IP protection worked. Its error identifies the conflict but does not take the technician to the saved record. Add `View existing device` so the user can inspect or correct the existing entry instead of guessing why saving failed.

### Importing

I pasted a device table including Subnet and Gateway. Both values were preserved as separate Notes lines, and the final summary correctly explained that importing is separate from confirming physical location or reachability.

The sequence still exposes many overlapping decisions: paste/upload, preview, suggested matches, confirmation settings, advanced matching, row review, and summary. Beginners can mistake a configuration screen for the final import action.

Suggested default path: `Choose source → Review detected columns and a few sample rows → Import and show results`. Keep detailed column controls under Advanced. Show the destination workspace and inventory name at every stage. Replace vague text such as `some source details may be kept in Notes` with a definite explanation: `Subnet and Gateway will be added to Notes`.

Some complete inventory rows can be saved automatically before the remaining flagged rows are reviewed. The remaining review screen has a `Cancel import` action. A technician may assume that Cancel undoes the whole operation. Rename it to `Stop and keep imported rows`, show a persistent saved-row count, and provide a way to undo the new records from an import after reviewing their effects.

Reimporting a revised spreadsheet does not necessarily update existing assignments: duplicates can be skipped. Make `Add new records only` explicit. A later `Review changes to existing records` mode should show differences before applying anything.

### Searching and consulting

I filtered to Studio and searched for a Bridge camera that existed elsewhere. The result was empty while the venue filter remained active. The current Clear control and no-results hint help, but a beginner can still conclude the record was never imported.

Show active-filter chips near the result count, a prominent `Clear all filters`, and `Search this workspace`. A global search can be a later improvement, with results grouped by Devices, IPTV, inventories, and equipment backups.

Notes preserve useful information, but Subnet, Gateway, and longer recovery instructions are harder to consult in a compact inline field. Add a read-focused record panel with full multiline notes, technical fields, confirmation dates, and copy actions. Keep editing a separate deliberate action.

The large product illustration and introductory hero appear inside working sections too. On a 1000-pixel-tall desktop viewport, much of the first screen is introduction and summary rather than records. Keep the fuller introduction on the homepage and use a compact header inside workspaces.

### Exporting and restoring

There are several meanings of export: the current filtered view, a complete inventory, all app data, and equipment configuration files under Backups. These are valid capabilities, but the distinction is easy to miss.

Full export/restore is available on the homepage. After opening a workspace, the controls disappear, and returning through the logo is not an obvious backup workflow. Add an explicit Home/Overview destination or a consistent full-backup entry point.

Before a report download, show its scope, for example `Export 1 matching device` or `Export all 84 devices`. Full-backup actions should say `Back up entire app` and `Restore app backup`. Consider renaming the Backups workspace to `Equipment backups` so technicians do not assume it backs up the AVTrack database.

The complete Excel workbook currently uses internal table names such as `equipment_inventories`, `import_preferences`, and `import_receipts`. A user-facing report should instead have Devices, IPTV, named inventories, and Equipment backups, with readable headings. Keep internal metadata in the restorable ZIP/JSON.

Restore already warns that it replaces current data and requires a checkbox. Strengthen this with a preview of the backup date, app/format version, workspace names, record counts, and attached-file counts. Create a recovery backup of the destination before replacement. Timestamp export filenames to reduce the chance of choosing an older file with the same name.

## Experienced broadcast supervisor review

### Trustworthy status and stock figures

Saved, imported, reviewed against a spreadsheet, physically located, physically counted, and operationally tested are different facts. The current `Confirm stock` dialog asks the user to check details against the old inventory file and explicitly leaves physical location separate. That is useful, but `Stock confirmed` can be read as a physical count.

Choose precise labels and explain what action each one records. Show the date, method, and optional technician initials for checks. Highlight stale or incomplete checks. Keep IP reachability and IPTV on-air status distinct from saved endpoint information.

Correct the location count and incomplete-quantity metrics before adding more dashboard numbers. Supervisors need to see unknowns, not just totals computed from the records that happen to be complete.

### Recovery confidence

A downloaded configuration file is not automatically the correct file for an incident. The equipment backup form has type, device/system name, filename, notes, and upload time, but model/serial, firmware compatibility, known-good status, and last successful restore test are not dedicated fields.

A practical improvement is to associate backups with an equipment/device record and show `Captured on`, `Compatible firmware`, and `Last restore tested`. Keep additional fields optional. A simple `known good / untested / superseded` state would help technicians choose the right file quickly.

The complete backup format also needs compatibility tests across app releases, integrity checks, and a safe recovery route if a restore is rejected. The current schema comparison requires matching database layouts. Avoid promising that every future version will restore every old backup until migration tests exist.

### Change control and provenance

Under pressure, importing an old spreadsheet or confirming the wrong item is more likely than a sophisticated technical failure. Keep import source, worksheet, source-row references, imported date, and skipped/changed outcomes accessible from the records they produced. Existing import sessions and receipts provide a useful foundation, but the path to that evidence should be obvious.

For stock reductions, record which serial was removed, the reason, and when. Prefer a movement/history record to silently reducing a number. A preview and undo/recovery route should accompany destructive bulk actions. Full user accounts need not be a prerequisite for optional reviewer initials on a trusted local installation.

### Incident lookup and handover

The first lookup during an outage should show the equipment identity, exact location, network endpoint, last verification, full notes, and associated known-good configuration files together. Today these facts are distributed across Devices, Inventory, Notes, and Backups. A record detail panel and lightweight links between related records would reduce context switching.

A handover view could later list: missing counts, unlocated items, records needing review, stale checks, and equipment without a known-good backup. Prioritize accurate existing data and clear exception lists before building more features.

## Suggested order of work

1. Fix complete JSON export, location metrics, unknown-count presentation, and ambiguous unit deletion. Add regression checks that exercise those exact behaviors.
2. Protect beginner work: draft preservation, explicit partial-import cancellation, restore preview, and pre-restore recovery backup.
3. Simplify the default import path, offer manual entry after inventory creation, clarify search scope/filter state, and show export scope before download.
4. Improve consultation: compact workspace headers, readable record details, precise confirmation labels/dates, and links to equipment backups.
5. Add lightweight handover and stock-movement history only after the existing paths are reliable.

## Evidence and limits

The existing 170 backend tests passed at the start of this review. Direct desktop scenarios nevertheless reproduced the JSON export failure and the metric issues above; passing the existing suite is not evidence of a bug-free app. The desktop walkthrough completed without JavaScript page errors. ZIP, Excel, and CSV export endpoints returned 200; their availability does not validate every possible real-world spreadsheet or restore scenario.

The two roles above are review perspectives using test data. No ship network, live IPTV feed, or actual equipment configuration restoration was tested. Suggestions are proposals, not implemented features.
