import base64
import io
import unittest
from openpyxl import Workbook
from spreadsheets import preview
import test_app


def encoded(raw, filename='inventory.xlsx', **extra):
    return dict(filename=filename, content=base64.b64encode(raw).decode(), **extra)


def workbook_bytes():
    book = Workbook()
    book.active.title = 'Cover'
    book.active.append(['AV inventory'])
    sheet = book.create_sheet('Devices')
    sheet.append(['Shipboard devices'])
    sheet.append(['Equipment', 'Location', 'IP Address', 'VLAN ID', 'System'])
    sheet.append(['ATEM', 'Liquid Lounge', '10.24.176.66', 1500, 'video'])
    sheet.append([None] * 5)
    sheet.append(['Console', 'Theater', '10.24.176.67', 1500, 'audio'])
    output = io.BytesIO()
    book.save(output)
    return output.getvalue()


class SpreadsheetParserTests(unittest.TestCase):
    def test_headerless_markdown_keeps_first_record_and_full_width(self):
        raw = b'''| RADIANCE | 1 | Forward Cam | Axis Q1755 | 239.252.4.2 | 1234 | 239.252.2.61 | 1234 | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RADIANCE | 5 | ESPN U | TRANSCODER | 239.252.5.37 | 1234 | 239.252.1.5 | 2000 | H.264 |
| RADIANCE | 17 | Insider TV | Castus | &#x9;239.252.2.17 | 1234 | 239.252.2.17 | 1234 | |'''
        result = preview(encoded(raw, 'channels.csv', pasted=True))
        self.assertTrue(result['generated_headers'])
        self.assertEqual(result['headers'], [f'Column {number}' for number in range(1, 10)])
        self.assertEqual(len(result['rows']), 3)
        self.assertEqual(result['rows'][0][2], 'Forward Cam')
        self.assertEqual(result['rows'][1][8], 'H.264')
        self.assertEqual(result['rows'][2][4], '239.252.2.17')

    def test_pasted_excel_rows_can_expand_beyond_header_width(self):
        raw = b'Channel\tIP\tPort\nForward Cam\t239.252.4.2\t1234\nESPN\t239.252.1.5\t2000\tH.264\n'
        result = preview(encoded(raw, 'channels.csv', pasted=True, delimiter='\t'))
        self.assertTrue(result['generated_headers'])
        self.assertEqual(result['headers'], ['Channel','IP','Port','Column 4'])
        self.assertEqual(result['rows'][0], ['Forward Cam','239.252.4.2','1234',''])
        self.assertEqual(result['rows'][1], ['ESPN','239.252.1.5','2000','H.264'])
        renamed = preview(encoded(raw, 'channels.csv', pasted=True, delimiter='\t', header_overrides=['Channel','Multicast IP','Port','Codec']))
        self.assertFalse(renamed['generated_headers'])
        self.assertEqual(renamed['headers'], ['Channel','Multicast IP','Port','Codec'])

    def test_worksheet_catalog_does_not_depend_on_header_row(self):
        result = preview(encoded(workbook_bytes(), sheets_only=True, header_row=50))
        self.assertEqual(result, {'sheets':['Cover','Devices']})

    def test_xlsx_sheet_header_and_numeric_cells(self):
        result = preview(encoded(workbook_bytes(), sheet='Devices', header_row=2))
        self.assertEqual(result['sheets'], ['Cover', 'Devices'])
        self.assertEqual(result['headers'][2], 'IP Address')
        self.assertEqual(result['rows'][0][3], '1500')
        self.assertEqual(result['row_numbers'], [3, 5])
        self.assertEqual(len(result['rows']), 2)

    def test_csv_bom_semicolon_quotes_blank_rows(self):
        raw = '\ufeffDevice;IP;VLAN\r\n"ATEM; main";10.24.176.66;1500\r\n;;\r\n'.encode()
        result = preview(encoded(raw, 'devices.csv'))
        self.assertEqual(result['headers'], ['Device', 'IP', 'VLAN'])
        self.assertEqual(result['rows'], [['ATEM; main', '10.24.176.66', '1500']])

    def test_unreadable_and_empty_files(self):
        for payload in (encoded(b'not excel'), encoded(b'data', 'old.xls'), encoded(b'a\nb', 'a.csv', header_row=0)):
            with self.subTest(payload=payload['filename']):
                with self.assertRaises(ValueError):
                    preview(payload)

    def test_blank_csv_cells_and_empty_sheets_are_successful_noops(self):
        for raw in (b'', b'\n\n', b'name,ip\n,,\n', b'Device ID,o.O\n123,o.O\n'):
            with self.subTest(raw=raw):
                result = preview(encoded(raw, 'empty.csv'))
                self.assertEqual(result['rows'], [])
                self.assertEqual(result['row_numbers'], [])
        result = preview(encoded(b'\n\nVENUE,DEVICE NAME,IP Adress\nRD POOL,Camera,\n', 'leading-blanks.csv'))
        self.assertEqual(result['headers'], ['VENUE', 'DEVICE NAME', 'IP Adress'])
        self.assertEqual(result['rows'], [['RD POOL', 'Camera', '']])
        self.assertEqual(result['row_numbers'], [4])

    def test_csv_ignored_columns_and_placeholder_cells_preserve_alignment(self):
        raw = (' Device_ID ,VENUE,o.O,DEVICE NAME,IP Adress,VLAN,Notes,o.O value\n'
               'old-id,RD MAIN LOUNGE,unwanted,ATEM,10.24.176.66,o.O, O.o ,unwanted\n'
               'id-only,o.O,unwanted,o.O,o.O,o.O,o.O,unwanted\n'
               'another-id,RD POOL,unwanted,Camera,10.24.176.67,1500,0.0,unwanted\n').encode()
        result = preview(encoded(raw, 'devices.csv'))
        self.assertEqual(result['headers'], ['VENUE', 'DEVICE NAME', 'IP Adress', 'VLAN', 'Notes'])
        self.assertEqual(result['ignored_columns'], ['Device_ID', 'o.O', 'o.O value'])
        self.assertEqual(result['rows'], [['RD MAIN LOUNGE', 'ATEM', '10.24.176.66', '', ''],
                                         ['RD POOL', 'Camera', '10.24.176.67', '1500', '0.0']])
        self.assertEqual(result['row_numbers'], [2, 4])

    def test_xlsx_ignored_columns_and_placeholder_cells(self):
        book = Workbook()
        book.active.append(['Device ID', 'Device name', 'o.O', 'VLAN', 'Notes'])
        book.active.append([123, 'ATEM', 'unwanted', 'o.O', 'keep o.O within longer notes'])
        book.active.append([456, 'o.O', 'unwanted', 'o.O', 'o.O'])
        book.active.append([789, 'Camera', 'unwanted', 1500, 0])
        output = io.BytesIO()
        book.save(output)
        result = preview(encoded(output.getvalue()))
        self.assertEqual(result['headers'], ['Device name', 'VLAN', 'Notes'])
        self.assertEqual(result['rows'], [['ATEM', '', 'keep o.O within longer notes'], ['Camera', '1500', '0']])
        self.assertEqual(result['row_numbers'], [2, 4])


class SpreadsheetHTTPTests(test_app.AppTests):
    # Reuse the isolated HTTP fixture; run only new cases in this subclass.
    test_cross_origin_and_assets = None
    test_csv_formula_protection = None
    test_duplicate_scope = None
    test_export_import_roundtrip_and_idempotence = None
    test_full_lifecycle_and_persistence = None
    test_import_is_atomic = None
    test_validation = None

    def test_preview_does_not_write_and_mapped_import_roundtrip(self):
        status, data = self.request('/api/spreadsheet-preview', 'POST', encoded(workbook_bytes(), sheet='Devices', header_row=2))
        self.assertEqual(status, 200)
        self.assertEqual(self.request('/api/devices')[1]['devices'], [])
        mapped = [dict(name=r[0], category='AV device', venue=r[1], ip=r[2], vlan=r[3], discipline=r[4].title(), notes='') for r in data['rows']]
        self.assertEqual(self.request('/api/import', 'POST', {'version':1,'devices':mapped})[1], {'added':2,'skipped':0})
        self.assertEqual(self.request('/api/import', 'POST', {'version':1,'devices':mapped})[1], {'added':0,'skipped':2})
        status, export = self.request('/api/export.csv')
        self.assertEqual(status, 200)
        data = self.request('/api/spreadsheet-preview', 'POST', encoded(export, 'export.csv'))[1]
        self.assertEqual(data['headers'], ['name','category','venue','discipline','ip','vlan','notes','record_type','channel_source','port'])
        self.assertEqual(len(data['rows']), 2)

    def test_invalid_excel_http(self):
        self.assertEqual(self.request('/api/spreadsheet-preview', 'POST', encoded(b'invalid'))[0], 400)
